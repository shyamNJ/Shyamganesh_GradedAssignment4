package com.example.springboot8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
